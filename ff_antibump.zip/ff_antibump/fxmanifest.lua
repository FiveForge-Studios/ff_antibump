------------------------------------------------------------------------------------
-- FiveForge Anti Bump
-- Configured By akaLucifer. & pyrs
-- Releasing or Claiming this as your own is against, this resources License
------------------------------------------------------------------------------------
fx_version "adamant"
game "gta5"

lua54 "yes"

files {
	"data/handlings/.meta",
}

-- Vehicles
data_file "HANDLING_FILE" "data/handlings/*.meta"